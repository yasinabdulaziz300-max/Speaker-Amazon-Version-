package com.speakercorepurger.app.ads

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier

/** Amazon Appstore build: no banner ads. */
@Suppress("UNUSED_PARAMETER")
@Composable
fun AdaptiveBanner(adUnitId: String, modifier: Modifier = Modifier) = Unit
