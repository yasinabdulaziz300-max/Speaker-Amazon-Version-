package com.speakercorepurger.app.ads

import android.app.Activity
import android.app.Application
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Amazon Appstore build: no Google ads and no Google Play Services (Fire devices do not have them).
 * Same public API as the Google build, but every ad format is switched off.
 */
@Suppress("UNUSED_PARAMETER")
class AdsManager(private val app: Application) {

    val bannerConfigured = false
    val interstitialConfigured = false
    val rewardedConfigured = false
    val bannerUnitId: String = ""

    private val _ready = MutableStateFlow(false)
    val ready: StateFlow<Boolean> = _ready.asStateFlow()

    private val _rewardedLoaded = MutableStateFlow(false)
    val rewardedLoaded: StateFlow<Boolean> = _rewardedLoaded.asStateFlow()

    private val _privacyOptionsRequired = MutableStateFlow(false)
    val privacyOptionsRequired: StateFlow<Boolean> = _privacyOptionsRequired.asStateFlow()

    fun gatherConsentAndStart(activity: Activity) = Unit

    fun showPrivacyOptions(activity: Activity) = Unit

    fun showInterstitialIfEligible(activity: Activity) = Unit

    fun showRewarded(activity: Activity, onResult: (Boolean) -> Unit) = onResult(false)
}
