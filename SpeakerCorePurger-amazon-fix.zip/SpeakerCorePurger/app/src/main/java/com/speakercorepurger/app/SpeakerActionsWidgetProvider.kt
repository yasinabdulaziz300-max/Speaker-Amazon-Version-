package com.speakercorepurger.app

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import com.speakercorepurger.app.R

/** Home-screen shortcuts that open a screen; they never start sound automatically. */
class SpeakerActionsWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, appWidgetIds: IntArray) {
        appWidgetIds.forEach { appWidgetId ->
            val views = RemoteViews(context.packageName, R.layout.widget_speaker_actions)
            views.setOnClickPendingIntent(
                R.id.widget_purge,
                screenPendingIntent(context, MainActivity.ROUTE_PURGE, 41),
            )
            views.setOnClickPendingIntent(
                R.id.widget_health,
                screenPendingIntent(context, MainActivity.ROUTE_HEALTH, 42),
            )
            views.setOnClickPendingIntent(
                R.id.widget_rescue,
                screenPendingIntent(context, MainActivity.ROUTE_RESCUE, 43),
            )
            manager.updateAppWidget(appWidgetId, views)
        }
    }

    private fun screenPendingIntent(context: Context, route: String, requestCode: Int): PendingIntent {
        val intent = Intent(context, MainActivity::class.java)
            .putExtra(MainActivity.EXTRA_ROUTE, route)
            .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        return PendingIntent.getActivity(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
    }
}
