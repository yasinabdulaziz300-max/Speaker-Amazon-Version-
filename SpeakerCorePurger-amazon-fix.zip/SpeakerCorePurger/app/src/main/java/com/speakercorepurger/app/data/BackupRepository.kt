package com.speakercorepurger.app.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import com.speakercorepurger.app.audio.CUSTOM_MAX_HZ
import com.speakercorepurger.app.audio.CUSTOM_MIN_HZ
import com.speakercorepurger.app.audio.DEFAULT_CUSTOM_HZ
import com.speakercorepurger.app.audio.DEFAULT_DURATION_SEC
import com.speakercorepurger.app.audio.PURGE_DURATIONS_SEC
import com.speakercorepurger.app.audio.PurgeMode
import kotlinx.coroutines.flow.first
import org.json.JSONArray
import org.json.JSONObject

enum class BackupRestoreResult { SUCCESS, INVALID, FAILED }

/** Versioned, local-file backup for all user-owned app data stored in Preferences DataStore. */
class BackupRepository(private val context: Context) {

    suspend fun exportJson(): String {
        val prefs = context.appDataStore.data.first()
        val settings = JSONObject()
            .put("onboardingDone", prefs[onboardingKey] ?: false)
            .put("theme", prefs[themeKey] ?: ThemeMode.SYSTEM.name)
            .put("vibrate", prefs[vibrateKey] ?: true)
            .put("autoMaxVolume", prefs[autoMaxVolumeKey] ?: false)
            .put("volumeCapPercent", prefs[volumeCapKey] ?: 80)
            .put("mode", prefs[modeKey] ?: PurgeMode.WATER.id)
            .put("durationSec", prefs[durationKey] ?: DEFAULT_DURATION_SEC)
            .put("customHz", prefs[customHzKey] ?: DEFAULT_CUSTOM_HZ)
            .put("extendedUnlockedUntil", prefs[extendedUntilKey] ?: 0L)
            .put("dryingEndsAt", prefs[dryingEndsKey] ?: 0L)
            .put("dynamicColor", prefs[dynamicColorKey] ?: false)
            .put("weeklyReminder", prefs[weeklyReminderKey] ?: false)

        return JSONObject()
            .put("format", FORMAT)
            .put("version", VERSION)
            .put("createdAt", System.currentTimeMillis())
            .put("settings", settings)
            .put("healthResults", prefs[healthResultsKey].orEmpty())
            .put("healthReference", prefs[healthReferenceKey] ?: JSONObject.NULL)
            .put("purgeHistory", prefs[historyKey] ?: "[]")
            .put("programs", prefs[programsKey].orEmpty())
            .toString(2)
    }

    suspend fun restoreJson(raw: String) {
        if (raw.length > MAX_BACKUP_CHARS) invalid("Backup file is too large")
        val root = try {
            JSONObject(raw)
        } catch (e: Exception) {
            invalid("Backup is not JSON")
        }
        if (root.optString("format") != FORMAT || root.optInt("version", -1) != VERSION) {
            invalid("Unsupported backup format")
        }

        val settings = root.optJSONObject("settings") ?: invalid("Missing settings")
        val onboardingDone = settings.boolean("onboardingDone")
        val theme = settings.string("theme").takeIf { value -> ThemeMode.entries.any { it.name == value } }
            ?: invalid("Invalid theme")
        val vibrate = settings.boolean("vibrate")
        val autoMaxVolume = settings.boolean("autoMaxVolume")
        val volumeCapPercent = settings.int("volumeCapPercent").takeIf { it in 30..100 }
            ?: invalid("Invalid volume cap")
        val mode = settings.string("mode").takeIf { value -> PurgeMode.entries.any { it.id == value } }
            ?: invalid("Invalid purge mode")
        val durationSec = settings.int("durationSec").takeIf { it in PURGE_DURATIONS_SEC }
            ?: invalid("Invalid purge duration")
        val customHz = settings.float("customHz").takeIf { it.isFinite() && it in CUSTOM_MIN_HZ..CUSTOM_MAX_HZ }
            ?: invalid("Invalid custom frequency")
        val extendedUnlockedUntil = settings.long("extendedUnlockedUntil").takeIf { it >= 0L }
            ?: invalid("Invalid unlock timestamp")
        val dryingEndsAt = settings.long("dryingEndsAt").takeIf { it >= 0L }
            ?: invalid("Invalid timer timestamp")
        val dynamicColor = settings.boolean("dynamicColor")
        val weeklyReminder = settings.boolean("weeklyReminder")

        val healthRaw = root.requiredString("healthResults")
        val healthLines = healthRaw.lineSequence().filter { it.isNotBlank() }.toList()
        val healthResults = HealthResult.decodeAll(healthRaw)
        if (healthResults.size != healthLines.size || healthResults.size > HealthResult.MAX_STORED ||
            healthResults.any { !isValidHealthResult(it) }
        ) {
            invalid("Invalid health history")
        }
        if (!root.has("healthReference")) invalid("Missing health reference")
        val reference = if (root.isNull("healthReference")) {
            null
        } else {
            HealthResult.decode(root.requiredString("healthReference"))
                ?: invalid("Invalid health reference")
        }
        if (reference != null && !isValidHealthResult(reference)) invalid("Invalid health reference")

        val historyRaw = root.requiredString("purgeHistory")
        validateHistory(historyRaw)
        val programsRaw = root.requiredString("programs")
        val programLines = programsRaw.lineSequence().filter { it.isNotBlank() }.count()
        if (ProgramCodec.decodeAll(programsRaw).size != programLines ||
            programLines > ProgramCodec.MAX_PROGRAMS
        ) {
            invalid("Invalid saved programs")
        }

        // Validate everything above before replacing any stored values.
        context.appDataStore.edit { prefs ->
            prefs[onboardingKey] = onboardingDone
            prefs[themeKey] = theme
            prefs[vibrateKey] = vibrate
            prefs[autoMaxVolumeKey] = autoMaxVolume
            prefs[volumeCapKey] = volumeCapPercent
            prefs[modeKey] = mode
            prefs[durationKey] = durationSec
            prefs[customHzKey] = customHz
            prefs[extendedUntilKey] = extendedUnlockedUntil
            prefs[dryingEndsKey] = dryingEndsAt
            prefs[dynamicColorKey] = dynamicColor
            prefs[weeklyReminderKey] = weeklyReminder
            if (healthRaw.isBlank()) prefs.remove(healthResultsKey) else prefs[healthResultsKey] = healthRaw
            if (reference == null) prefs.remove(healthReferenceKey)
            else prefs[healthReferenceKey] = reference.encode()
            if (historyRaw == "[]") prefs.remove(historyKey) else prefs[historyKey] = historyRaw
            if (programsRaw.isBlank()) prefs.remove(programsKey) else prefs[programsKey] = programsRaw
        }
    }

    private fun validateHistory(raw: String) {
        val entries = try {
            JSONArray(raw)
        } catch (e: Exception) {
            invalid("Invalid purge history")
        }
        if (entries.length() > MAX_HISTORY) invalid("Purge history is too long")
        for (index in 0 until entries.length()) {
            val entry = entries.optJSONObject(index) ?: invalid("Invalid purge history entry")
            val mode = entry.optString("m")
            val validMode = mode == PROGRAM_MODE || PurgeMode.entries.any { it.id == mode }
            val startedAt = entry.opt("t") as? Number
            val plannedValue = entry.opt("p") as? Number
            val playedValue = entry.opt("d") as? Number
            val planned = plannedValue?.toInt() ?: -1
            val played = playedValue?.toInt() ?: -1
            val completed = entry.opt("c") as? Boolean
            if (!validMode || startedAt == null || startedAt.toLong() < 0L ||
                plannedValue == null || playedValue == null || completed == null ||
                planned !in 1..MAX_SESSION_SECONDS || played !in 0..planned ||
                (!entry.isNull("h") && (
                    entry.opt("h") !is Number ||
                        entry.optInt("h", -1) !in CUSTOM_MIN_HZ.toInt()..CUSTOM_MAX_HZ.toInt()
                    )) ||
                (!entry.isNull("l") && entry.opt("l") !is String)
            ) {
                invalid("Invalid purge history entry")
            }
        }
    }

    private fun isValidHealthResult(result: HealthResult): Boolean =
        result.takenAt > 0L &&
            result.bands.size == HEALTH_FREQUENCIES.size &&
            result.bands.map { it.hz }.toSet() == HEALTH_FREQUENCIES &&
            result.bands.all { it.peakDb.isFinite() && it.snrDb.isFinite() }

    private fun JSONObject.string(name: String): String =
        if (has(name) && opt(name) is String) getString(name) else invalid("Missing $name")

    private fun JSONObject.requiredString(name: String): String =
        if (has(name) && !isNull(name) && opt(name) is String) getString(name) else invalid("Missing $name")

    private fun JSONObject.boolean(name: String): Boolean =
        if (has(name) && opt(name) is Boolean) getBoolean(name) else invalid("Missing $name")

    private fun JSONObject.int(name: String): Int =
        if (has(name) && opt(name) is Number) getInt(name) else invalid("Missing $name")

    private fun JSONObject.long(name: String): Long =
        if (has(name) && opt(name) is Number) getLong(name) else invalid("Missing $name")

    private fun JSONObject.float(name: String): Float =
        if (has(name) && opt(name) is Number) getDouble(name).toFloat() else invalid("Missing $name")

    private fun invalid(reason: String): Nothing = throw IllegalArgumentException(reason)

    private companion object {
        const val FORMAT = "speaker-core-purger-backup"
        const val VERSION = 1
        const val MAX_BACKUP_CHARS = 2_000_000
        const val MAX_HISTORY = 100
        const val MAX_SESSION_SECONDS = 1_200
        const val PROGRAM_MODE = "program"
        val HEALTH_FREQUENCIES = setOf(250, 500, 1_000, 2_000, 3_500, 5_000, 8_000, 10_000)

        // Keep these preference names aligned with SettingsRepository and the existing repositories.
        val onboardingKey = booleanPreferencesKey("onboarding_done")
        val themeKey = stringPreferencesKey("theme")
        val vibrateKey = booleanPreferencesKey("vibrate")
        val autoMaxVolumeKey = booleanPreferencesKey("auto_max_volume")
        val volumeCapKey = intPreferencesKey("volume_cap_percent")
        val modeKey = stringPreferencesKey("mode")
        val durationKey = intPreferencesKey("duration_sec")
        val customHzKey = floatPreferencesKey("custom_hz")
        val extendedUntilKey = longPreferencesKey("extended_unlocked_until")
        val dryingEndsKey = longPreferencesKey("drying_ends_at")
        val dynamicColorKey = booleanPreferencesKey("dynamic_color")
        val weeklyReminderKey = booleanPreferencesKey("weekly_reminder")
        val healthResultsKey = stringPreferencesKey("health_results")
        val healthReferenceKey = stringPreferencesKey("health_reference")
        val historyKey = stringPreferencesKey("history_json")
        val programsKey = stringPreferencesKey("programs")
    }
}
